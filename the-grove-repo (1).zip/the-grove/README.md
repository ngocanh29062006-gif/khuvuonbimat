# THE GROVE – A Living World of Stock Market Knowledge

Thế giới học chứng khoán dạng khu biệt thự giữa rừng. Một file `index.html`, không cần build.

## Cấu trúc nội dung
Dữ liệu nằm trong biến `V` (biệt thự → căn nhà → phòng học) và `Q` (quiz) ở cuối `index.html`.
Mỗi phòng: `R(tiêu đề, nguồn, [các ý], widget)`. Nguồn bắt đầu bằng "Bổ sung" sẽ hiện nhãn vàng.

## Chạy thử
Mở `index.html` bằng trình duyệt.

## Nguồn nội dung
SSI – Khóa đào tạo Phân tích Kỹ thuật (Ngày 1–4) và SSI Notebook. Nội dung tham khảo, không phải lời khuyên đầu tư.

## Cập nhật
Thêm engine minh họa chuyển động `wAn` (đường giá, nến, cột, vùng, nhãn xuất hiện lần lượt, có nút Phát lại) và nội dung từ "Tài liệu chuyên sâu" (ODT) và "Bảng tổng hợp" (Excel). Phần mở rộng nằm trong khối `NEW` và `SC` ngay trước `const done`. Mỗi biệt thự có hàng rào và cổng riêng.
